#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <dirent.h>
#include <netdb.h>
#include <ctype.h>
#include <stdbool.h>

// size of buffer for data transfer
#define BUFFER_SIZE 512
// folder conatining all files on the client side
#define DSKTP "./client_desktop/"

void error(char *msg);
bool  compare(char *a, char*b);
void putfile(int sockfd,char* fname,int client, int server);
void receivefile(int sockfd,char* fname,int client, int server);
void getfile(int sockfd, char* fname,int client , int server);
bool fileExist(char *fname);

int main(int argc, char const *argv[])
{
	// Checking whether the number of arguments in input is correct or not
	int num_args;
	if (argc != 3)
	{
		printf("Invalid input format. The correct input format is\n./server <Server IP Address><Server Port number>\n");
		exit(1);
	}

	// basic declaraion
	int file_exist;
	struct sockaddr_in address;
	num_args=argc;
	int sockfd;
	struct sockaddr_in serv_addr;
	char buffer[BUFFER_SIZE];
	bzero(buffer, BUFFER_SIZE);

	// socket creation
	int cnctn;
	int portno = atoi(argv[2]);
	const char* IP = argv[1];
	int num_files;
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd<0){
		error("Failed to create a socket. Exiting! ");
	}
	cnctn=0;

	// server address configuration
	int f_edit;
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(portno);
	if(inet_pton(AF_INET, IP, &serv_addr.sin_addr)<=0){ 
		error("\nERROR : The given IP address is not supported. ");
	}
	int client;

	if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0){
		error("\nError: Failed to connect to the remote host. ");
	}
	cnctn++;

	while(1){
		int server;
		bzero(buffer, BUFFER_SIZE);
		fgets(buffer, BUFFER_SIZE, stdin);
		buffer[strcspn(buffer, "\n")] = 0;
		client=1;

		// decide for the correct operation from put/get/mget/mput
		char cmd_line[BUFFER_SIZE];
		strcpy(cmd_line,buffer);
		char* cmd = strtok(cmd_line," \t");
		server=0;

		// If operation is put
		if (compare("PUT",cmd))
		{
			// check if file exist
			f_edit=0;
			char *fname;
			cmd =  strtok(NULL," \t");
			fname = cmd;
			num_files=1;
			if (!fileExist(fname)){
				printf("ERROR: File %s not found.\n", fname);
				continue;
			}
			file_exist=1;
			// send command to server
			printf("CLIENT : transferring %s to server.\n",buffer );
			send(sockfd, buffer, BUFFER_SIZE, 0);
			server=1;
			client=0;
			putfile(sockfd, fname, client,server);
			bzero(buffer, BUFFER_SIZE);
            		recv(sockfd, buffer, BUFFER_SIZE, 0);
            		server=0;
            		client=1;
            		if (!compare(buffer,"SUCCESS")){
            			printf("The file was not sent. Try again\n");
            			break;
            		}
            	}
		else if (compare("GET",cmd))
		{
			// check if file exist
			f_edit=0;
			char *fname;
			cmd =  strtok(NULL," \t");
			fname = cmd;
			num_files=1;

			// send command to server
			send(sockfd, buffer, BUFFER_SIZE, 0);
			server=1;
			client=0;

			// Check for server reponse
			getfile(sockfd, fname,client,server);
			
		}
		else if (compare("MPUT",cmd))
		{
			// send(sockfd, buffer, BUFFER_SIZE, 0);
			
			char *fext, *fname;
			cmd =  strtok(NULL," ");
			fext = cmd;
			f_edit=0;
			printf("Sending all %s files\n\n",fext );
			DIR *di;
			struct dirent *dir;
			num_files=0;
			di = opendir(DSKTP);
			dir=readdir(di);
			while (dir != NULL){
				fname= dir->d_name;
				char* ext = strrchr(fname, '.');
				if (compare(ext,fext))
				{
					file_exist=1;
					bzero(buffer,BUFFER_SIZE);
					strcpy(buffer,"PUT ");
					strcat(buffer,fname);
					printf("Sending %s to server\n",buffer );
					send(sockfd, buffer, BUFFER_SIZE, 0);
					server=1;
					client=0;
					putfile(sockfd,fname,client,server);
					bzero(buffer, BUFFER_SIZE);
                    			recv(sockfd, buffer, BUFFER_SIZE, 0);
                    			client=1;
                    			server=0;
                    			if (!compare(buffer,"SUCCESS"))
                    			{
                    				printf("Some error occurred\n");
                    				break;
                    			}
                    			num_files++;
				}
				dir=readdir(di);
			}
			
			closedir(di);
		}
		else if (compare("MGET",cmd)){
			client=1;
			server=0;
			char *fext, *fname;
			cmd =  strtok(NULL," ");
			fext = cmd;
			num_files=0;
			printf("Getting all %s files\n",fext );

			// send command to server
			
			send(sockfd, buffer, BUFFER_SIZE, 0);
			while(1){
				bzero(buffer, BUFFER_SIZE);
				recv(sockfd, buffer, BUFFER_SIZE, 0);
				f_edit=0;
				if (!compare(buffer,"OVER")){
					char fname[BUFFER_SIZE];
					strcpy(fname, buffer);
					// printf("%s\n",buffer );
					if (fileExist(fname)){
						file_exist=1;
						printf("Do you want to overwrite the file %s (y/n) ? ",fname);
						bzero(buffer, BUFFER_SIZE);
						fgets(buffer, BUFFER_SIZE, stdin);
						buffer[strcspn(buffer, "\n")] = 0;
						num_files++;
						if (compare(buffer,"y")){
							f_edit=1;
							bzero(buffer, BUFFER_SIZE);
							strcpy(buffer, "SEND");
							send(sockfd, buffer, BUFFER_SIZE, 0);
							server=1;
							client=0;
							bzero(buffer, BUFFER_SIZE);
							printf("Receiving file content for %s\n",fname );
							receivefile(sockfd,fname,client,server);
							server=0;
							client=1;
							bzero(buffer, BUFFER_SIZE);
	                        			strcpy(buffer, "READY");
	                        			send(sockfd, buffer, BUFFER_SIZE, 0);
	                        			server=1;
	                        			client=0;
						}
						else{
							f_edit=0;
							bzero(buffer, BUFFER_SIZE);
							strcpy(buffer, "SKIP");
							send(sockfd, buffer, BUFFER_SIZE, 0);
						}
					}
					else{
						file_exist=0;
						bzero(buffer, BUFFER_SIZE);
						strcpy(buffer, "SEND");
						send(sockfd, buffer, BUFFER_SIZE, 0);
						client=0;
						server=1;
						bzero(buffer, BUFFER_SIZE);
						printf("Receiving file content for %s\n",fname );
						receivefile(sockfd,fname,client,server);
						client=1;
						server=0;
						//receivefile(sockfd,fname);
						bzero(buffer, BUFFER_SIZE);
                        			strcpy(buffer, "READY");
                        			send(sockfd, buffer, BUFFER_SIZE, 0);
                        			client=0;
						server=1;
					}
				}
				else{
					printf("All files received\n");
					bzero(buffer, BUFFER_SIZE);
					strcpy(buffer, "DONE");
					send(sockfd, buffer, BUFFER_SIZE, 0);
					client=0;
					server=1;
					break;
				}
			}
		}
		else if (compare("EXIT",buffer)){
			num_files=0;
			send(sockfd, buffer, BUFFER_SIZE, 0);
			break;
		}
		else{
			num_files=0;
			printf("Invalid Command given.\n");
			continue;
		}
		printf("File Transfer Protocol successful!!\n\n");	
	}
	close(sockfd);
	return 0;
}

void error(char *msg){
	perror(msg);
	exit(0);
}

bool  compare(char *a, char*b)
{
	if(strcmp(a,b)==0)
	{
		return true;
	}
	return false;
}
bool fileExist(char *fname){
	bool x = false;
	DIR *di;
	struct dirent *dir;
	di = opendir(DSKTP);
	dir = readdir(di);
	while (dir != NULL){
		if(compare(dir->d_name,fname)){
			x=true;
			break;
		}
		dir = readdir(di);
	}
	closedir(di);
	return x;
}

void getfile(int sockfd, char* fname, int client , int server){
	char buffer[BUFFER_SIZE];
	bzero(buffer,BUFFER_SIZE);
	recv(sockfd, buffer, BUFFER_SIZE, 0);
	int num_files;
	int f_edit;
	int file_exist;

	if (compare(buffer,"ABORT"))
	{
		f_edit=0;
		printf("Operation aborted1.\n");
		num_files++;
	}
	else if (compare(buffer,"READY"))
	{
		num_files++;
		if (fileExist(fname))
		{
			printf("Do you want to overwrite the file (y/n) ? ");
			bzero(buffer, BUFFER_SIZE);
			fgets(buffer, BUFFER_SIZE, stdin);
			file_exist=1;
			buffer[strcspn(buffer, "\n")] = 0;
			send(sockfd, buffer, BUFFER_SIZE, 0);
			client=0;
			if (compare(buffer,"y"))
			{
				
				//receivefile(sockfd, fname);
				server=1;
				receivefile(sockfd,fname,client,server);
				f_edit=1;
				// printf("FIle can be received\n");

			}
			else{
				printf("Sending no to server\n");
				recv(sockfd, buffer, BUFFER_SIZE, 0);
				client=1;
				server=0;
				if (!compare("ABORT",buffer))
				{
					printf("Unexpected response from server\n");
				}
				printf("Operation aborted2.\n");
				f_edit=0;
			}
		}
		else{
			num_files++;
			bzero(buffer,BUFFER_SIZE);
			strcpy(buffer,"y");
			send(sockfd, buffer, BUFFER_SIZE, 0);
			client=0;
			server=1;
			bzero(buffer, BUFFER_SIZE);
			//receivefile(sockfd, fname);
			receivefile(sockfd,fname,client,server);
			bzero(buffer, BUFFER_SIZE);
			file_exist=0;
			f_edit=1;
		}
	}
	else{
		printf("File %s not found.\n",fname);//Operation Aborted\n", fname);
	}
}

void receivefile(int sockfd,char* fname,int client , int server){
	char buffer[BUFFER_SIZE];
    	char fpath[BUFFER_SIZE];
    	int num_files;
    	strcpy(fpath,DSKTP);
    	strcat(fpath,fname);
    	int f_edit;
	int file_exist;
	FILE *fp = fopen(fpath, "wb");
    	if(fp == NULL){
    		file_exist=0;
        	printf("File %s: Can not create file on your pc.\n", fname);
    	}
    	else{
        	bzero(buffer, BUFFER_SIZE); 
        	int out_file_block_size = 0;
        	file_exist=1;
        	out_file_block_size = recv(sockfd, buffer, BUFFER_SIZE, 0);
        	while(out_file_block_size > 0) {
        		f_edit=1;
            		int write_size = fwrite(buffer, sizeof(char), out_file_block_size, fp);
            		if(write_size < out_file_block_size){
                		error("File write could not be done.");
            		}
            		num_files=0;
            		//clearing buffer
            		bzero(buffer, BUFFER_SIZE);
            		if (out_file_block_size == 0 || out_file_block_size != BUFFER_SIZE ){
                		break;
            		}
            		out_file_block_size = recv(sockfd, buffer, BUFFER_SIZE, 0);
            		f_edit=0;
        	}
        	num_files++;
        	if(out_file_block_size < 0){
        		f_edit=0;
            		if (errno == EAGAIN){
                		printf("recv() timed out.\n");
            		}
            		else{
                		fprintf(stderr, "recv() failed due to errno = %d\n", errno);
                		exit(1);
            		}
            		num_files=0;
        	}
        	printf("Received the file from Server's Disk!\n\n");
        	fclose(fp); 
    	}
}

void putfile(int sockfd,char* fname,int client,int server){
	// Check for server reponse
	char buffer[BUFFER_SIZE];
	int file_exist;
	bzero(buffer,BUFFER_SIZE);
	recv(sockfd, buffer, BUFFER_SIZE, 0);
	int f_edit;
	if (compare(buffer,"ABORT")){
		printf("Operation aborted1.\n");
	}
	int num_files;
	if (compare(buffer,"OK")){
		printf("File not present in Server's Disk! \n\n");
		char buffer[BUFFER_SIZE];
    		char fpath[BUFFER_SIZE];
    		num_files++;
    		strcpy(fpath,DSKTP);
    		strcat(fpath,fname);
		FILE *fp = fopen(fpath, "r");
		f_edit=1;
    		if(fp == NULL){
        		printf("ERROR: File %s not found or unable to open.\n", fname);
    		}
    		//clearing buffer
    		bzero(buffer, BUFFER_SIZE); 
    		file_exist=1;
    		int file_block_size;
    		file_block_size = fread(buffer, sizeof(char), BUFFER_SIZE, fp);
    		while(file_block_size > 0){
        		if(send(sockfd, buffer, file_block_size, 0) < 0){
            			fprintf(stderr, "ERROR: Failed to send file %s. (errno = %d)\n", fname, errno);
            			break;
        		}
        		file_exist++;
        		bzero(buffer, BUFFER_SIZE);
        		file_block_size = fread(buffer, sizeof(char), BUFFER_SIZE, fp);
    		}
    		f_edit=0;
    		fclose(fp);
	}
	else{
		printf("File already present in Server's disk! \nDo you wish to overwrite the File %s ? (y/n)\n",fname);
		bzero(buffer, BUFFER_SIZE);
		fgets(buffer, BUFFER_SIZE, stdin);
		buffer[strcspn(buffer, "\n")] = 0;
		send(sockfd, buffer, BUFFER_SIZE, 0);
		client=0;
		server=1;
		if (compare(buffer,"y"))
		{
			bzero(buffer,BUFFER_SIZE);
			recv(sockfd, buffer, BUFFER_SIZE, 0);
			f_edit=1;
			// printf("CLIENT response OK %s\n",buffer );
			if (compare(buffer,"OK"))
			{
				char buffer[BUFFER_SIZE];
    				char fpath[BUFFER_SIZE];
    				strcpy(fpath,DSKTP);
    				file_exist=1;
    				strcat(fpath,fname);
				FILE *fp = fopen(fpath, "r");
    				if(fp == NULL){
        				printf("ERROR: File %s not found or unable to open.\n", fname);
    				}
    				num_files++;
    				//clearing buffer
    				bzero(buffer, BUFFER_SIZE); 
    				int file_block_size;
    				file_block_size = fread(buffer, sizeof(char), BUFFER_SIZE, fp);
    				f_edit=0;
    				while(file_block_size > 0){
        				if(send(sockfd, buffer, file_block_size, 0) < 0){
            					fprintf(stderr, "ERROR: Failed to send file %s. (errno = %d)\n", fname, errno);
            					break;
        				}
        				f_edit=1;
        				bzero(buffer, BUFFER_SIZE);
        				file_block_size = fread(buffer, sizeof(char), BUFFER_SIZE, fp);
    				}
    				f_edit=0;
    				fclose(fp);
				bzero(buffer, BUFFER_SIZE);
			}
			else{
				printf("Operation aborted.\n");
				num_files=0;
			}
			printf("File Transfer Protocol Completed! \n\n");
		}
		else{
			recv(sockfd, buffer, BUFFER_SIZE, 0);
			server=0;
			if (!compare("ABORT",buffer))
			{
				printf("Unexpected response from server\n");
			}
			client=1;
			printf("Operation aborted.\n\n");
		}
	}
}
