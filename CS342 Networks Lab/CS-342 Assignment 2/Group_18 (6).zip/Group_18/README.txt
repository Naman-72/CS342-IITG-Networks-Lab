Socket-based-FTP

The following is an implementation of File Transfer Protocol using TCP sockets in C.

It has the following four commands : PUT , GET , MPUT , MGET

File overwrite feature has been implemented along with it i.e. if the destination has a file with the same name of the file to be transferred, the client will be asked whether to overwrite the file or not.
About the code

The source code for server and client is given in "server.c" and "client.c".

The folders ‘server_desktop’ and ‘client_desktop’ act as the server’s and client’s disk. All the files are transferred within them. Each program, client and the server, reads their respective folder to keep a record of the files in their disk.

For compiling the server code : gcc server.c -o server

For compiling the client code : gcc client.c -o client

Command to run the server code : ./server <Server Port number>

Command to run the client code : ./client <Server IP Address> <Server Port number>

After running the code, enter the commands in client’s terminal in valid format. The server code needs to executed once and shall be closed using “Ctrl + C” in the server machine. Every client on execution develops a connection with the server and the same socket connection is maintained. until the client program exit. USE COMMAND “EXIT” to quit client program. This will disconnect the client. Running the client program again shall develop a new connection again with the existing server if it is still active.

Valid format of Commands:

    PUT : PUT <filename>
    GET : GET <filename>
    MGET : MGET <extension including dot> ( For example : MGET .c)
    MPUT : MPUT <extension including dot> ( For example : MPUT .txt )

Assumptions:

1)The user shall give the input in valid format. Incomplete command or illegal characters in the command might lead to runtime crash and has not been handled assuming user shall provide the command in proper format.
2)Filename must be a string of ASCII characters without space and having length less than BUFFER_SIZE ( default is 512 bytes), a macros mentioned in the files ‘server.c’ and ‘client.c’. To send file with larger filenames, you must modify the macros and recompile.
3)The folder ‘client_desktop’ and ‘server_desktop’ are taken to be the disk of server and client node. This is to ensure that the program can be evaluated and tested on any machine easily without worrying about addressing problem. Folder with these names should exist even before starting the execution otherwise segmentation fault will be there.


