#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <dirent.h>
#include <netdb.h>
#include <ctype.h>
#include <stdbool.h>

// size of buffer for data transfer
#define BUFFER_SIZE 512
// maximum number of connections at a time
#define MAX_CONN 7
#define DSKTP "./server_desktop/"

/*
This code is the implementation of server in File Tranfer Protocol using TCP(Transmission Control Protocol) connection using socket programming in C. This implementation is done in the linux.

To compile this program , use the following command in terminal : gcc server.c -o server

To run the compiled code , use the following command in terminal : ./server <Server Port number>
*/

//Some integer variables are declared in between that can be used to get the information about the system at any point of time.

void error(char *msg){
	perror(msg);
	exit(0);
}
bool compare(char*a, char*b)
{
	if(strcmp(a,b)==0)
	{return true;}
	return false;
}
bool fileExist(char *fname){
	bool x = false;
	DIR *di;
	struct dirent *dir;
	di = opendir(DSKTP);
	dir=readdir(di);
	while (dir != NULL){
		if(compare(dir->d_name,fname)){
			x=true;
			break;
		}
		dir=readdir(di);
	}
	closedir(di);
	return x;
}

int main(int argc, char const *argv[])
{
	//no_args denote the number of arguments in the input.
	int no_args;
	if (argc != 2){
		printf("Invalid number of operands in input. The correct format is\n");
		printf("<executable code> <Server Port number>\n");
		exit(1);
	}

	int portno,sockfd;
	no_args=argc;
	struct sockaddr_in cli_addr;
	char buffer[BUFFER_SIZE];
	// clearing useless data from buffer
	bzero(buffer, BUFFER_SIZE);
	int server;

	portno = atoi(argv[1]);
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd<0){
		error("Failed to create a socket. Exiting!");
	}
	int num_conn;

	// configuring the details of client address
	cli_addr.sin_family = AF_INET;
	cli_addr.sin_addr.s_addr = INADDR_ANY;
	cli_addr.sin_port = htons(portno);
	num_conn=0;

	// Binding the socket
	if (bind(sockfd,(struct sockaddr*)&cli_addr,(socklen_t)sizeof(cli_addr)) < 0){
		error("Connection/Binding failed. Exiting!");
	}
	server=1;

	// Listening to the port with MAX_CONN denoting maximum connections
	if (listen(sockfd, MAX_CONN)<0){
		error("Unable to listen to the port. Check the number of connections.");
	}
	else{
		num_conn++;
	}
	
	// Taking input
	while(1){
		int newsockfd;
		int addr_len = sizeof(cli_addr);
        	printf("Waiting for the connection to establish..\n");
        	int num_files;
        	newsockfd = accept(sockfd, (struct sockaddr*)&cli_addr, (socklen_t*)&addr_len);
        	int f_edit;

		if(newsockfd < 0){
			error("ERROR: error on accept");
		}
        	printf("Connection received\n");
        	int client;
        	int file_exist;
		
		while(1){
			// receive command from user
			f_edit=0;
			char input_copy[BUFFER_SIZE];
			num_files=0;
			recv(newsockfd, buffer, BUFFER_SIZE, 0);
			char cmd_line[BUFFER_SIZE];
			strcpy(cmd_line,buffer);
			strcpy(input_copy,cmd_line);
			client=0;
			char* cmd = strtok(cmd_line," \t");
			printf("%s\n",cmd );
			
			if (compare(cmd,"EXIT")){
				printf("Exiting\n");
				num_files=0;
				client=0;
				f_edit=0;
				file_exist=0;
				break;
			}
			else if (compare(cmd,"GET")){
				num_files++;
				char *fname;
				// getting file name
                		cmd =  strtok(NULL," \t");
                		fname = cmd;

                		char buffer[BUFFER_SIZE];
    				if(fileExist(fname)){
    					num_files++;
        				printf("File found on Server\n");
        				//Clearing buffer to send file
        				bzero(buffer, BUFFER_SIZE);
        				strcpy(buffer,"READY");
					file_exist=1;
        				send(newsockfd,buffer,BUFFER_SIZE,0);
        				client=1;
        				server=0;
        				// To get response to overwrite or not if file laready exists on client
					recv(newsockfd, buffer, BUFFER_SIZE,0);
					client=0;
					server=1;
        				// printf("Response on ready : %s\n",buffer );
        				if(compare(buffer,"y")){
            					char buffer[BUFFER_SIZE];
            					//int num3;
            					f_edit=1;
            					// fpath contains path of the file
    						char fpath[BUFFER_SIZE];
    						strcpy(fpath,DSKTP);
    						strcat(fpath,fname);
    						file_exist=1;

    						//opening file in read format
    						f_edit=1;
    						FILE *fp = fopen(fpath, "r");
    						if(fp == NULL){
    							file_exist=0;
        						printf("ERROR: Could not open the file %s.Check the file name once again\n", fname);
    						}
						else{
							//clearing buffer for file tranfer
    							bzero(buffer, BUFFER_SIZE); 
							file_exist=1;
    							int file_block_size;
    							file_block_size = fread(buffer, sizeof(char), BUFFER_SIZE, fp);
    							while(file_block_size > 0){
        							if(send(newsockfd, buffer, file_block_size, 0) < 0){
            								fprintf(stderr, "ERROR: Failed to send file %s. (errno = %d)\n", fname, errno);

            								break;
        							}
        							//clearing buffer
        							bzero(buffer, BUFFER_SIZE);
        							file_block_size = fread(buffer, sizeof(char), BUFFER_SIZE, fp);
								f_edit=1;
    							}
    						}
    						fclose(fp);
    						f_edit=0;
    						file_exist=0;
        				}
        				else{
        					file_exist=1;
            					printf("Response : No\n");
            					bzero(buffer,BUFFER_SIZE);
            					f_edit=0;

            					// To denote that the opertion was aborted by client
            					strcpy(buffer,"ABORT");
            					//sending ABORT signal to client
            					send(newsockfd,buffer,BUFFER_SIZE,0);
            					client=1;
            					server=2;

            					printf("File transfer was aborted\n");
        				}
        				printf("File Transfer protocol Completed!\n\n");
    				}
    				else{
        				bzero(buffer, BUFFER_SIZE);
        				printf("No such file exist on server.\n");
        				// to cancel the tranfer
        				file_exist=0;
        				f_edit=2;

        				strcpy(buffer,"CANCEL");
        				send(newsockfd,buffer,BUFFER_SIZE,0);
        				client=1;
        				server=2;
    				}
                	}
			else if (strcmp(cmd,"PUT")==0){
				server=1;
				client=0;
				char *fname;
				//getting file name
				cmd =  strtok(NULL," \t");
				fname = cmd;

                		//put_file(newsockfd, fname);
                		char buffer[BUFFER_SIZE];
				if(fileExist(fname)){
					file_exist=1;
					printf("File already found on server.\n");
        				printf("Do you wish to overwrite the File Contents?\n");
        				bzero(buffer, BUFFER_SIZE);
        				strcpy(buffer,"CONTINUE");
        				send(newsockfd,buffer,BUFFER_SIZE,0);
        				server=0;
        				client=1;
					bzero(buffer, BUFFER_SIZE);
        				recv(newsockfd, buffer, BUFFER_SIZE,0);
        				server=1;
        				client=0;
        				printf("Response : %s\n",buffer );

        				if(compare(buffer,"y")){
        					f_edit=1;
            					bzero(buffer, BUFFER_SIZE);
            					strcpy(buffer,"OK");
            					send(newsockfd,buffer,BUFFER_SIZE,0);
            					char buffer[BUFFER_SIZE];
    						char fpath[BUFFER_SIZE];
    						strcpy(fpath,DSKTP);
    						num_files=1;

    						strcat(fpath,fname);
						FILE *fp = fopen(fpath, "wb");
    						if(fp == NULL){
        						printf("File %s : Cannot create file on server.\n", fname);
    						}
    						else{
        						bzero(buffer, BUFFER_SIZE); 
        						int out_file_block_size = 0;
        						out_file_block_size = recv(newsockfd, buffer, BUFFER_SIZE, 0);
        						client=1;
        						server=2;

        						while(out_file_block_size > 0){
            							int write_size = fwrite(buffer, sizeof(char), out_file_block_size, fp);
            							if(write_size < out_file_block_size){
            								f_edit=0;
                							error("ERROR : File writing was failed on server.");
            							}
            							//clearing buffer
            							bzero(buffer, BUFFER_SIZE);
            							if (out_file_block_size == 0 || out_file_block_size != BUFFER_SIZE ){
                							break;
            							}
								f_edit=1;
            							out_file_block_size = recv(newsockfd, buffer, BUFFER_SIZE, 0);
        						}
        						if(out_file_block_size < 0){
        							f_edit=0;
            							if (errno == EAGAIN){
                							printf("recv() timed out.\n");
            							}
            							else{
                							fprintf(stderr, "recv() failed due to errno = %d\n", errno);
                							exit(1);
            							}
        						}
        						printf("Received file from Client!\n\n");
        						fclose(fp); 
        						client=0;
        						server=1;
    						}
            					printf("File sucessfully received\n\n");
            					num_files=0;
        				}
        				else{
            					bzero(buffer,BUFFER_SIZE);
            					strcpy(buffer,"ABORT");
            					f_edit=0;

            					send(newsockfd,buffer,BUFFER_SIZE,0);
            					printf("Aborted file tranfer\n\n");
        				}
    				}
    				else{
        				printf("File not already present in the server's disk.\nReady to receive the file!\n\n");
        				bzero(buffer, BUFFER_SIZE);
        				f_edit=1;
        				num_files=1;
        				strcpy(buffer,"OK");

        				send(newsockfd,buffer,BUFFER_SIZE,0);
        				client=1;
        				char buffer[BUFFER_SIZE];
    					char fpath[BUFFER_SIZE];
    					strcpy(fpath,DSKTP);

    					strcat(fpath,fname);
					FILE *fp = fopen(fpath, "wb");
    					if(fp == NULL){
    						file_exist=0;
        					printf("File %s : Cannot create file on server.\n", fname);
    					}
    					else{
    						f_edit=1;
        					bzero(buffer, BUFFER_SIZE); 
        					int out_file_block_size = 0;

        					out_file_block_size = recv(newsockfd, buffer, BUFFER_SIZE, 0);
        					client=1;
        					server=2;
        					while(out_file_block_size > 0){
            						int write_size = fwrite(buffer, sizeof(char), out_file_block_size, fp);
            						if(write_size < out_file_block_size){
                						error("ERROR : File writing was failed on server.");
            						}
            						//clearing buffer
            						bzero(buffer, BUFFER_SIZE);
            						if (out_file_block_size == 0 || out_file_block_size != BUFFER_SIZE ){
                						break;
            						}
							file_exist=1;
							f_edit=0;
            						out_file_block_size = recv(newsockfd, buffer, BUFFER_SIZE, 0);
        					}
        					if(out_file_block_size < 0){
        						f_edit=0;
            						if (errno == EAGAIN){
                						printf("recv() timed out.\n");
            						}
            						else{
                						fprintf(stderr, "recv() failed due to errno = %d\n", errno);
                						exit(1);
            						}
        					}
						f_edit=0;
						num_files=0;
        					printf("Received file from Client!\n\n");
        					fclose(fp); 
    					}
    				}
                		//clearing buffer
                		bzero(buffer,BUFFER_SIZE);
                		strcpy(buffer,"SUCCESS");
                		send(newsockfd, buffer, BUFFER_SIZE, 0);
			}
			else if (strcmp(cmd,"MGET")==0){
                		char *fext, *fname;
                		cmd =  strtok(NULL," ");
                		fext = cmd;
				num_files=0;
				server=1;
				client=0;
                		printf("Sending all %s files\n",fext );
				DIR *di;
                		struct dirent *dir;
                		di = opendir(DSKTP);
                		bzero(buffer,BUFFER_SIZE);
                		f_edit=0;

                		//dir = readdir(di);
                		while ((dir = readdir(di)) != NULL){
                    			fname= dir->d_name;
                    			char* ext = strrchr(fname, '.');
                    			if (ext==NULL){
                    				f_edit=0;
                        			continue;
                    			}
                    			if (strcmp(ext,fext)==0){
                        			bzero(buffer,BUFFER_SIZE);
                        			strcpy(buffer,fname);

                        			printf("%s to be sent to client\n",buffer );
                        			f_edit=1;
                        			send(newsockfd, buffer, BUFFER_SIZE, 0);
                        			client=1;
                        			server=0;
                        			bzero(buffer, BUFFER_SIZE);
                        			recv(newsockfd, buffer, BUFFER_SIZE, 0);
                        			client=0;
                        			server=1;
                        			printf("%s\n",buffer );
						file_exist=1;
                        			if (strcmp(buffer,"SKIP")==0){
                        				num_files++;
                        				f_edit=0;
                            				continue;
                        			}
                        			else if (strcmp(buffer,"SEND")==0){
                            				bzero(buffer,BUFFER_SIZE);
                            				num_files++;
                            				
                            				printf("Sending file %s to Client's Disk\n\n",fname );
                            				char buffer[BUFFER_SIZE];
    							char fpath[BUFFER_SIZE];

    							strcpy(fpath,DSKTP);
    							strcat(fpath,fname);
    							f_edit=1;
    							FILE *fp = fopen(fpath, "r");
    							if(fp == NULL){
    								f_edit=0;
        							printf("ERROR: Could not open the file %s. Check the file name once again\n", fname);
    							}
							else{
    								bzero(buffer, BUFFER_SIZE); 
    								int file_block_size; 
    								file_block_size = fread(buffer, sizeof(char), BUFFER_SIZE, fp);
    								while(file_block_size > 0){
        								if(send(newsockfd, buffer, file_block_size, 0) < 0){

            									fprintf(stderr, "ERROR: Failed to send file %s. (errno = %d)\n", fname, errno);
            									break;
        								}
        								bzero(buffer, BUFFER_SIZE);
        								f_edit=1;
        								file_block_size = fread(buffer, sizeof(char), BUFFER_SIZE, fp);
    								}
    							}
    							fclose(fp);
                        			}
						bzero(buffer, BUFFER_SIZE);
                        			recv(newsockfd, buffer, BUFFER_SIZE, 0);
                        			if (!compare(buffer,"READY")){
                            				printf("Some error occured\n");
                            				break;
                        			}
                        		}
                        		//dir = readdir(di);
                		}
                		bzero(buffer,BUFFER_SIZE);
                		strcpy(buffer,"OVER");
                		num_files=0;
                		f_edit=0;
                		file_exist=0;
                		send(newsockfd, buffer, BUFFER_SIZE, 0);
                		bzero(buffer, BUFFER_SIZE);
                		recv(newsockfd, buffer, BUFFER_SIZE, 0);
                		printf("All files of type %s sent\n",fext );
				closedir(di);
				client=0;
			}
			else{
				printf("\nInvalid\n");
			}
			bzero(buffer, BUFFER_SIZE);
		}
    		close(newsockfd);
        	printf("Connection closed\n");	
	}
	close(sockfd);
	server=0;
	return 0;
}
