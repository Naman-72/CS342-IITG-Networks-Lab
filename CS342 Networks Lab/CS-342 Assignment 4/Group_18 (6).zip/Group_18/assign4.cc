#include <bits/stdc++.h>
#define Num_Packets 10000000
#define KB 1024
typedef uint32_t uint;
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/internet-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/ipv4-global-routing-helper.h"
#include "ns3/gnuplot.h"
using namespace ns3;
using namespace std;
int ip_assigned=0; // whether IP is assigned yet or not.

NS_LOG_COMPONENT_DEFINE ("CS342 Assignment-4 Group-18");

//Declaration of all the functions used in the program
int hybla_used=0;   //tells which TCP agent is used for simulation
//ip_assigned=0;
int westwood_used=0;
static void congestWindowSize(Ptr<OutputStreamWrapper> stream, double startTime, uint oldCwnd, uint newCwnd);
//hybla_used=0;
int yeah_used=0;
//yeah_used=0;
//westwood_used=0;
static void dropPackets(Ptr<OutputStreamWrapper> stream, double startTime, uint flow_id);
int tcp_used=0;    // whether tcp is used or not
int flow_type=2; //0 for single flow , 1 for multi flow
//flow_type=2;
void goodput_calculate(Ptr<OutputStreamWrapper> stream, double startTime, string context, Ptr<const Packet> p, const Address& addr);
//packet_dropped=0;
//packet_sent=0;
int gp_calculated=0;
int tp_calculated=0;
int cw_calculated=0;
//gp_calculated=0;
//tp_calculated=gp_calculated;
//cw_calculated=0;
//socket_created=0;
void throughput_calculate(Ptr<OutputStreamWrapper> stream, double startTime, string context, Ptr<const Packet> p, Ptr<Ipv4> ipv4, uint interface);
//pf_measure=0;
int pf_measure=0;
Ptr<Socket> Create_Socket(Address sinkAddress, 
					uint sinkPort, 
					string tcpVariant, 
					Ptr<Node> hostNode, 
					Ptr<Node> sinkNode, 
					double startTime, 
					double stopTime,
					uint packetSize,
					uint numPackets,
					string dataRate,
					double appStartTime,
					double appStopTime);
//gp_calculated=cw_calculated;
int socket_created=0;

//Declaration of the global variables used in the program
map<uint, uint> dropped_packets; 
//initz_done=0;
int initz_done=0;
map<Address, double> total_bytes_gput;
//store_done=0;
int store_done=0;			  
map<string, double> total_bytes_tput;//f_created=0;
int f_created=0;	  
map<string, double> max_throughput;	
//fm_used=0;	  
int fm_used=0;   //flow monitor used or not;	
char types[3][40]={"TcpHybla","TcpWestwood+","TcpYeah"};
int packet_dropped=0;
double tput_kbps;
int packet_sent=0;
double gput_kbps;

/* The definition of class APP and all its associated functions has been copied from ns-3 tutorial */

class APP: public Application {
private:
	virtual void StartApplication(void);
	virtual void StopApplication(void);

	void ScheduleTx(void);
	void SendPacket(void);

	Ptr<Socket>     mSocket;
	int             app_started;
	Address         mPeer;
	int             app_stopped;
	uint32_t        mPacketSize;
	uint32_t        mNPackets;
	int             curr_status;  // tells about the current status of the program
	DataRate        mDataRate;
	EventId         mSendEvent;
	int             app_scheduled;
	bool            mRunning;
	uint32_t        mPacketsSent;

public:
	APP();
	virtual ~APP();

	void Setup(Ptr<Socket> socket, Address address, uint packetSize, uint nPackets, DataRate dataRate){
		mSocket = socket;
		app_started=0;
		mPeer = address;
		app_stopped=0;
		mPacketSize = packetSize;
		curr_status=0;
		mNPackets = nPackets;
		app_scheduled=0;
		mDataRate = dataRate;
	};
	void ChangeRate(DataRate newRate){
		mDataRate = newRate;
		return;
	};
		// void recv(int numBytesRcvd);

};

APP::APP(): mSocket(0),
mPeer(),
mPacketSize(0),
mNPackets(0),
mDataRate(0),
mSendEvent(),
mRunning(false),
mPacketsSent(0) {
}

APP::~APP() {
	mSocket = 0;
}

void APP::StartApplication() {
	mRunning = true;
	app_started=1;
	mPacketsSent = 0;
	app_stopped=0;
	mSocket->Bind();
	app_scheduled=0;
	mSocket->Connect(mPeer);
	curr_status=1;
	SendPacket();
	return;
}

void APP::StopApplication() {
	curr_status=1;
	mRunning = false;
	app_started=0;
	if(mSendEvent.IsRunning()) {
		Simulator::Cancel(mSendEvent);
		app_stopped=1;
		curr_status=0;
	}
	if(mSocket) {
		mSocket->Close();
		app_stopped=1;
		curr_status=0;
	}
	app_scheduled=0;
	return;
}

void APP::SendPacket() {
	app_started=1;
	app_stopped=0;
	Ptr<Packet> packet = Create<Packet>(mPacketSize);
	packet_sent++;
	packet_dropped--;
	mSocket->Send(packet);
	app_scheduled=0;
	if(++mPacketsSent < mNPackets) {
		ScheduleTx();
	}
	curr_status=1;
	return;
}



void APP::ScheduleTx() {
	app_started=1;
	app_stopped=0;
	if (mRunning) {
		app_scheduled++;
		Time tNext(Seconds(mPacketSize*8/static_cast<double>(mDataRate.GetBitRate())));
		curr_status=1;
		mSendEvent = Simulator::Schedule(tNext, &APP::SendPacket, this);
	}
	return;
}



//Stores time vs congestion window size in file
static void congestWindowSize(Ptr<OutputStreamWrapper> stream, double startTime, uint oldCwnd, uint newCwnd){

	// storing time elapsed till now and current congestion window size into given filestream
	cw_calculated=0;
	pf_measure=1;
	*stream->GetStream() << Simulator::Now ().GetSeconds () - startTime << "\t" << newCwnd << endl; 
	cw_calculated=1;
}


static void dropPackets(Ptr<OutputStreamWrapper> stream, double startTime, uint flow_id) {

	//if a packet is getting dropped due to buffer overflow, we store the time of drop in the file
	packet_dropped++;
	*stream->GetStream() << Simulator::Now ().GetSeconds () - startTime << "\t" << endl; 
	packet_sent--;
	if(dropped_packets.find(flow_id) == dropped_packets.end()) {  //this flow got a packet dropped for the first time
		dropped_packets[flow_id] = 0;							  // hence initialising to zero
		store_done=1;
	}
	tcp_used=1;
	dropped_packets[flow_id]+=1; //incrementing the number of dropped packets
	return;
}


// Function to calculate goodput and store the data into file
void goodput_calculate(Ptr<OutputStreamWrapper> stream, double startTime, string context, Ptr<const Packet> p, const Address& addr){

	gp_calculated=0;
	tcp_used=1;
	double current_time = Simulator::Now().GetSeconds();
	store_done=0;
	if(total_bytes_gput.find(addr) == total_bytes_gput.end()) //if first packet received by flow
		total_bytes_gput[addr] = 0;
	pf_measure=tcp_used;
	total_bytes_gput[addr] += p->GetSize();
	gp_calculated+=tcp_used;					  //adding current packet size
	gput_kbps = (((total_bytes_gput[addr] * 8.0) / KB)/(current_time-startTime)); //calculating goodput
	store_done++;
	*stream->GetStream() << current_time-startTime << "\t" <<  gput_kbps << endl;	   //storing in file
	return;
}

// Function to calculate throughput and store the data into file
void throughput_calculate(Ptr<OutputStreamWrapper> stream, double startTime, string context, Ptr<const Packet> p, Ptr<Ipv4> ipv4, uint interface) {

	tcp_used=1;
	double current_time = Simulator::Now().GetSeconds();
	tp_calculated=0;

	//if first packet received by flow
	
	if(total_bytes_tput.find(context) == total_bytes_tput.end())
		total_bytes_tput[context] = 0;
	packet_sent++;
	if(max_throughput.find(context) == max_throughput.end())
		max_throughput[context] = 0;

	total_bytes_tput[context] += p->GetSize();			//adding current packet size
	ip_assigned*=2;
	tput_kbps = (((total_bytes_tput[context] * 8.0) / KB)/(current_time-startTime)); //calculating throughput
	pf_measure=1;
	*stream->GetStream() << current_time-startTime << "\t" <<  tput_kbps << endl;	      //storing in file
	store_done=1;
	if(max_throughput[context] < tput_kbps)				//updating max throughput if required
		max_throughput[context] = tput_kbps;
	tp_calculated++;
	return;
}

// A function that accepts all the required values, assigns them to corresponding attributes and returns an ns3 TCP socket
Ptr<Socket> Create_Socket(Address sinkAddress, 
					uint sinkPort, 
					string tcpVariant, 
					Ptr<Node> hostNode, 
					Ptr<Node> sinkNode, 
					double startTime, 
					double stopTime,
					uint packetSize,
					uint numPackets,
					string dataRate,
					double appStartTime,
					double appStopTime) {

	
		socket_created=0;
		int variant=0;
		tcp_used=0;
		//assigning variant type
		if(tcpVariant.compare("TcpHybla") == 0) {
			variant=1;
			tcp_used*=2;
			tcp_used++;
		}
		else if(tcpVariant.compare("TcpWestwood+") == 0) {
			variant=2;
			tcp_used++;
		}
		else if(tcpVariant.compare("TcpYeah") == 0) {
			variant=3;
			tcp_used++;
		}
		switch(variant){
			case 1:
				Config::SetDefault("ns3::TcpL4Protocol::SocketType", TypeIdValue(TcpHybla::GetTypeId()));
				hybla_used++;
				break;
			case 2:
				Config::SetDefault("ns3::TcpL4Protocol::SocketType", TypeIdValue(TcpWestwood::GetTypeId()));
				westwood_used++;
				break;
			case 3:
				Config::SetDefault("ns3::TcpL4Protocol::SocketType", TypeIdValue(TcpYeah::GetTypeId()));
				yeah_used++;
				break;
			default:
				fprintf(stderr, "Invalid TCP version\n");
				westwood_used=0;
				hybla_used=westwood_used;
				yeah_used=westwood_used;
				exit(EXIT_FAILURE);
		}
	PacketSinkHelper packetSinkHelper("ns3::TcpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(), sinkPort));
	ApplicationContainer sinkApps = packetSinkHelper.Install(sinkNode);
	gp_calculated=0;
	sinkApps.Start(Seconds(startTime));
	tp_calculated=gp_calculated;
	sinkApps.Stop(Seconds(stopTime));

	Ptr<Socket> ns3TcpSocket = Socket::CreateSocket(hostNode, TcpSocketFactory::GetTypeId());
	cw_calculated=tp_calculated;
	
	//creating the APP
	Ptr<APP> app = CreateObject<APP>();
	pf_measure=0;
	app->Setup(ns3TcpSocket, sinkAddress, packetSize, numPackets, DataRate(dataRate));
	initz_done++;
	hostNode->AddApplication(app);
	app->SetStartTime(Seconds(appStartTime));
	socket_created=1;
	app->SetStopTime(Seconds(appStopTime));
	fm_used=0;

	return ns3TcpSocket;
}

void Create_files(int i,Ptr<OutputStreamWrapper> * tput,
	Ptr<OutputStreamWrapper> * cwnd,
	Ptr<OutputStreamWrapper> * closs,
	Ptr<OutputStreamWrapper> * gput,
	int type)
{	AsciiTraceHelper asciiTraceHelper;
	f_created=0;
	 string filename=types[i];
	cw_calculated=1;
	if(type==1)
		filename= filename+"_trace_a";
	else
		filename= filename+"_trace_b";
	cwnd[i] = asciiTraceHelper.CreateFileStream(filename+".cw");  //file to store congestion window data for i-th network type
	tp_calculated=cw_calculated;
	closs[i] = asciiTraceHelper.CreateFileStream(filename+".cl"); //file to store congestion loss data for i-th network type
	gp_calculated=1;
	tput[i] = asciiTraceHelper.CreateFileStream(filename+".tp");  //file to store throughput data for i-th network type
	f_created++;
	gput[i] = asciiTraceHelper.CreateFileStream(filename+".gp");  //file to store goodput data for i-th network type
	return;
}

void statsStorage(map<FlowId, FlowMonitor::FlowStats> stats,
	Ptr<OutputStreamWrapper> *closs,
	Ptr<Ipv4FlowClassifier> classifier)
{		
for (map<FlowId, FlowMonitor::FlowStats>::const_iterator i = stats.begin(); i != stats.end(); ++i) {
	store_done=0;
	Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow (i->first);
	int type=-1;
	if(t.sourceAddress == "15.1.0.1") {
		type=0;} 
	else if(t.sourceAddress == "15.1.1.1") {
		type=1;} 
	else if(t.sourceAddress == "15.1.2.1") {
		type=2;}
	ip_assigned=1;
	
	switch(type){
	
		case 0: 
		*closs[type]->GetStream()<<"** TCP Hybla Flow **\n"<<"Flow ID :"<<i->first<<"\n";
		hybla_used=1;	
		*closs[type]->GetStream()<<"Maximum throughput attained: "<<max_throughput["/NodeList/5/$ns3::Ipv4L3Protocol/Rx"]<<endl;
		break;
		case 1: 
		*closs[type]->GetStream()<<"** TCP Westwood+ Flow **\n"<<"Flow ID :"<<i->first<<"\n";
		westwood_used=1;
		*closs[type]->GetStream()<<"Maximum throughput attained: "<<max_throughput["/NodeList/6/$ns3::Ipv4L3Protocol/Rx"]<<endl;
		break;
		case 2:
		*closs[type]->GetStream()<<"** TCP YeAH-TCP Flow **\n"<<"Flow ID :"<<i->first<<"\n";
		yeah_used=1;
		*closs[type]->GetStream()<<"Maximum throughput attained: "<<max_throughput["/NodeList/7/$ns3::Ipv4L3Protocol/Rx"]<<endl;
		break;
	
	
	}
	
	tcp_used=1;
	if(type>=0){
		if(dropped_packets.find(type+1)==dropped_packets.end())
			dropped_packets[type+1] = 0;
		packet_dropped=0;
		packet_sent++;
		*closs[type]->GetStream()<<"Source IP: "<< t.sourceAddress << " -> Destination IP: "<<t.destinationAddress<<endl;
		pf_measure++;
		*closs[type]->GetStream()<<"Total number of packets to be transmitted: "<<Num_Packets<<endl;
		gp_calculated=1;
		*closs[type]->GetStream()<<"Total number of packets lost: "<<i->second.lostPackets<<endl;
		tp_calculated=1;
		*closs[type]->GetStream()<<"Total number of packets transmitted successfully: "<<Num_Packets-(i->second.lostPackets)<<endl;
		cw_calculated=1;
		*closs[type]->GetStream()<<"Total number of packets lost due to buffer overflow: "<< dropped_packets[type+1]<<endl;
		fm_used=1;
		*closs[type]->GetStream()<<"Total number of packets lost due to congestion: "<<i->second.lostPackets - dropped_packets[type+1]<<endl;
		*closs[type]->GetStream()<<"% loss of packets due to buffer overflow: "<<(dropped_packets[type+1]*100.0)/Num_Packets<<endl;
		f_created++;
		*closs[type]->GetStream()<<"% loss of packets due to congestion: "<<((i->second.lostPackets - dropped_packets[type+1])*100.0)/Num_Packets<<endl;

	}
	store_done++;
}
return;
}


void multipleFlow(int x)
{
	ip_assigned+=x;
	ip_assigned++;
	Ipv4InterfaceContainer Receiver_Interfaces;
	hybla_used=x+1;
	NodeContainer Senders,Routers,Receivers;
	westwood_used=hybla_used;
	yeah_used=2*x+1;
    // initialize 
    Routers.Create(2);
	Senders.Create(3);
	Receivers.Create(3);
	int PacketSize = 1.3*1024;

    string R2RBandwidth = "10Mbps";
    string R2RDelay = "50ms";
    string R2RQueueSize = to_string(500000/PacketSize)+"p"; 

    string H2RBandwidth = "100Mbps";
    string H2RDelay = "20ms";
    string H2RQueueSize = to_string(2000000/PacketSize)+"p"; 

    PointToPointHelper p2pRR;
    p2pRR.SetDeviceAttribute("DataRate",StringValue(R2RBandwidth));
    p2pRR.SetChannelAttribute("Delay",StringValue(R2RDelay));
    p2pRR.SetQueue("ns3::DropTailQueue", "MaxSize", StringValue(R2RQueueSize));
    PointToPointHelper p2pHR;
    p2pHR.SetDeviceAttribute("DataRate",StringValue(H2RBandwidth));
    p2pHR.SetChannelAttribute("Delay",StringValue(H2RDelay));
    p2pHR.SetQueue("ns3::DropTailQueue", "MaxSize", StringValue(H2RQueueSize));

    double error = 0.000001;
    Ptr<RateErrorModel> Error_Model = CreateObjectWithAttributes<RateErrorModel>("ErrorRate", DoubleValue (error));

    // INSTALLATION OF NET DEVICES
    // Now storing NIC of each router node
    NetDeviceContainer routerDevices = p2pRR.Install(Routers);
    // leftRouterDevices : netdevice on the router for left half
    // rightRouterDevices : netdevice on the router for right half
    // sender devices : the device on the sender host present in left half 
    // reciver devices : the device on the sender host present in right half 
    NetDeviceContainer leftRouterDevices, rightRouterDevices, senderDevices, receiverDevices;
    for (int i = 0; i < 3; i++)
    {
        NetDeviceContainer leftConfig = p2pHR.Install(Routers.Get(0),Senders.Get(i));
        NetDeviceContainer rightConfig = p2pHR.Install(Routers.Get(1),Receivers.Get(i));
        leftRouterDevices.Add(leftConfig.Get(0));
        senderDevices.Add(leftConfig.Get(1));
        rightRouterDevices.Add(rightConfig.Get(0));
        receiverDevices.Add(rightConfig.Get(1));
        leftConfig.Get(0)->SetAttribute("ReceiveErrorModel", PointerValue(Error_Model));
        rightConfig.Get(0)->SetAttribute("ReceiveErrorModel", PointerValue(Error_Model));
    }
    
	//Installing Internet Stack
	cout << "Installing internet stack on the nodes..."<< endl;
    InternetStackHelper stack;
    stack.Install(Routers);
    stack.Install(Senders);
    stack.Install(Receivers);

	//Assigning IP addresses to the nodes
	cout << "Assigning IP addresses to the nodes and initialising network interfaces..."<< endl;
	Ipv4AddressHelper routerIP = Ipv4AddressHelper("15.3.0.0", "255.255.255.0");	//(network IP, mask)
	Ipv4AddressHelper senderIP = Ipv4AddressHelper("15.1.0.0", "255.255.255.0");
	Ipv4AddressHelper ReceiverIP = Ipv4AddressHelper("15.2.0.0", "255.255.255.0");

    // NOW INTERFACE CONTAINER
    // pair of Ptr<Ipv4> and interface index. Typically ns-3 Ipv4Interfaces are installed on devices using an Ipv4 address helper. The helper's Assign() method takes a NetDeviceContainer which holds some number of Ptr<NetDevice>. For each of the NetDevices in the NetDeviceContainer the helper will find the associated Ptr<Node> and Ptr<Ipv4>. It makes sure that an interface exists on the node for the device and then adds an Ipv4Address according to the address helper settings (incrementing the Ipv4Address somehow as it goes). 
	Ipv4InterfaceContainer router_Interface, sender_Interfaces,leftRouter_Interfaces, rightRouter_Interfaces;
	router_Interface = routerIP.Assign(routerDevices);

	int i=0;
	while(i<3) 
	{
		NetDeviceContainer senderDevice;
		senderDevice.Add(senderDevices.Get(i));
		senderDevice.Add(leftRouterDevices.Get(i));

		Ipv4InterfaceContainer sender_Interface = senderIP.Assign(senderDevice);
		sender_Interfaces.Add(sender_Interface.Get(0));
		leftRouter_Interfaces.Add(sender_Interface.Get(1));
		senderIP.NewNetwork();

		NetDeviceContainer ReceiverDevice;
		ReceiverDevice.Add(receiverDevices.Get(i));
		ReceiverDevice.Add(rightRouterDevices.Get(i));
		
		Ipv4InterfaceContainer Receiver_Interface = ReceiverIP.Assign(ReceiverDevice);
		Receiver_Interfaces.Add(Receiver_Interface.Get(0));
		rightRouter_Interfaces.Add(Receiver_Interface.Get(1));
		ReceiverIP.NewNetwork();
		i++;
	}
	//Initialising the network
	tcp_used=1;
	if(x==1){
		packet_dropped=1;
		packet_sent=0;
		//cout << "Packet is dropped. multipleFlow was used\n";
	}
	else{
		packet_sent=1;
		packet_dropped=0;
	}
	flow_type-=2;
	flow_type-=x;
	flow_type*=x;
	flow_type++;
	double Duration_Gap = 100;
	pf_measure=1;
	double FirstFlowStart = 0;  //first flow starts at time 0
	initz_done=1;
	double OtherFlowStart = 20; //time when other flows start, while first one in progress
	store_done=x+1;
	uint port = 9000;
	f_created=1;
	fm_used=1;
	string Transfer_Speed  = "400Mbps";
	
	// arrays to store output streams for Throughput, Congestion Window, Congestion Loss, Goodput data respectively for each TCP variant
	Ptr<OutputStreamWrapper> *tput=new Ptr<OutputStreamWrapper>[3];
	gp_calculated++;
	Ptr<OutputStreamWrapper> *cwnd=new Ptr<OutputStreamWrapper>[3];
	tp_calculated++;
	Ptr<OutputStreamWrapper> *closs=new Ptr<OutputStreamWrapper>[3];
	cw_calculated++;
	Ptr<OutputStreamWrapper> *gput=new Ptr<OutputStreamWrapper>[3];
	tp_calculated-=x;

	// array to store ns3 TCP sockets for each TCP variant
	cw_calculated-=x;
	Ptr<Socket>* ns3TCPSocket = new Ptr<Socket>[3];

	//array to store sink values for Goodput
	 string * sink1= new string[3];
	gp_calculated+=x;
	sink1[0]="/NodeList/5/ApplicationList/0/$ns3::PacketSink/Rx";
	int link_no=0;
	sink1[1]="/NodeList/6/ApplicationList/0/$ns3::PacketSink/Rx";
	link_no++;
	sink1[2]="/NodeList/7/ApplicationList/0/$ns3::PacketSink/Rx";
	link_no++;
	
	//array to store sink values for Throughput
	 string * sink2= new string[3];
	link_no++;
	sink2[0]="/NodeList/5/$ns3::Ipv4L3Protocol/Rx";
	link_no++;
	sink2[1]="/NodeList/6/$ns3::Ipv4L3Protocol/Rx";
	link_no++;
	sink2[2]="/NodeList/7/$ns3::Ipv4L3Protocol/Rx";
	link_no++;
	
	int router_no;
	for(int i=0;i<3;i++){
		cout<<"From H"<<i+1<<" to H"<<i+4<<" : ";
		cout<<"Connection type: "<<types[i]<<endl;
		f_created++;
		Create_files(i,tput,cwnd,closs,gput,2); //create files to store data

		// assigning attributes to ns3 TCP sockets
		packet_sent++;
		if(i==0) //First flow starts at FirstFlowStart=0
			ns3TCPSocket[i] = Create_Socket(InetSocketAddress(Receiver_Interfaces.GetAddress(i), port), port,types[i], Senders.Get(i), Receivers.Get(i), FirstFlowStart, FirstFlowStart+Duration_Gap, PacketSize, Num_Packets, Transfer_Speed , FirstFlowStart, FirstFlowStart+Duration_Gap);
			
		else     //Other flows start at FirstFlowStart+OtherFlowStart = 20, while first one in progress
			ns3TCPSocket[i] = Create_Socket(InetSocketAddress(Receiver_Interfaces.GetAddress(i), port), port,types[i], Senders.Get(i), Receivers.Get(i), OtherFlowStart, OtherFlowStart+Duration_Gap, PacketSize, Num_Packets, Transfer_Speed , OtherFlowStart, OtherFlowStart+Duration_Gap);
			
			
		packet_sent--;
		
		ns3TCPSocket[i]->TraceConnectWithoutContext("CongestionWindow", MakeBoundCallback (&congestWindowSize, cwnd[i], 0));
		router_no=1;
		ns3TCPSocket[i]->TraceConnectWithoutContext("Drop", MakeBoundCallback (&dropPackets, closs[i], 0, i+1));
		router_no*=2;
		
		// Measuring packet sinks
		Config::Connect(sink1[i], MakeBoundCallback(&goodput_calculate, gput[i], 0));
		ip_assigned--;
		Config::Connect(sink2[i], MakeBoundCallback(&throughput_calculate, tput[i], 0));

	}

	cout<<endl;
	x++;

	cout<<"Filling Routing Tables"<< endl;
	store_done=x;
	Ipv4GlobalRoutingHelper::PopulateRoutingTables();
	initz_done-=x;

	// Enabling IP flow monitoring on all the nodes 
	cout<<"Setting up the FlowMonitor to enable IP flow monitoring on all the nodes..."<<endl;
	fm_used=x-1;
	Ptr<FlowMonitor> flowmon;
	FlowMonitorHelper flowmonHelper;
	fm_used=1;
	flowmon = flowmonHelper.InstallAll();
	fm_used=x-1;
	Simulator::Stop(Seconds(OtherFlowStart+Duration_Gap));

	// Simulation starts
	pf_measure=0;
	cout<<"Simulation is starting!"<< endl;
	Simulator::Run();
	pf_measure=x;
	
	cout<<"Checking for the packets that are lost"<< endl;
	flowmon->CheckForLostPackets();
	packet_dropped++;

	Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier>(flowmonHelper.GetClassifier());
	//int host_no=x+5;

	// Retrieving all collected the flow statistics
	cout<<"Collecting the flow statistics"<< endl;
	router_no=0;
	map<FlowId, FlowMonitor::FlowStats> stats = flowmon->GetFlowStats();
	link_no=0;
	statsStorage(stats,closs,classifier);
	x--;

	Simulator::Destroy();
	initz_done=0;
	cout << "Simulation is finished!  " << endl;
	x=0; 
	if(x==1){
		packet_dropped=1;
		packet_sent=0;
		//cout << "Packet is dropped. uniFlow was used.\n";
	}
	else{
		packet_sent=1;
		packet_dropped=0;
	}

	return;
}


void uniFlow(int x) 
{
	
	Ipv4InterfaceContainer Receiver_Interfaces;
	ip_assigned=1;
	NodeContainer Senders,Routers,Receivers;
	int host_no;
	if(x==1){
		packet_dropped=1;
		packet_sent=0;
		//cout << "Packet is dropped. uniFlow was used.\n";
	}
	else{
		packet_sent=1;
		packet_dropped=0;
	}
	//Initialising the network
	int link_no;
	hybla_used=1;
	Routers.Create(2);
	Senders.Create(3);
	Receivers.Create(3);
	int PacketSize = 1.3*1024;

    string R2RBandwidth = "10Mbps";
    string R2RDelay = "50ms";
    string R2RQueueSize = to_string(500000/PacketSize)+"p"; 

    string H2RBandwidth = "100Mbps";
    string H2RDelay = "20ms";
    string H2RQueueSize = to_string(2000000/PacketSize)+"p"; 

    PointToPointHelper p2pRR;
    p2pRR.SetDeviceAttribute("DataRate",StringValue(R2RBandwidth));
    p2pRR.SetChannelAttribute("Delay",StringValue(R2RDelay));
    p2pRR.SetQueue("ns3::DropTailQueue", "MaxSize", StringValue(R2RQueueSize));
    PointToPointHelper p2pHR;
    p2pHR.SetDeviceAttribute("DataRate",StringValue(H2RBandwidth));
    p2pHR.SetChannelAttribute("Delay",StringValue(H2RDelay));
    p2pHR.SetQueue("ns3::DropTailQueue", "MaxSize", StringValue(H2RQueueSize));

    double error = 0.000001;
    Ptr<RateErrorModel> Error_Model = CreateObjectWithAttributes<RateErrorModel>("ErrorRate", DoubleValue (error));

    // INSTALLATION OF NET DEVICES
    // Now storing NIC of each router node
    NetDeviceContainer routerDevices = p2pRR.Install(Routers);
    // leftRouterDevices : netdevice on the router for left half
    // rightRouterDevices : netdevice on the router for right half
    // sender devices : the device on the sender host present in left half 
    // reciver devices : the device on the sender host present in right half 
    NetDeviceContainer leftRouterDevices, rightRouterDevices, senderDevices, receiverDevices;
    for (int i = 0; i < 3; i++)
    {
        NetDeviceContainer leftConfig = p2pHR.Install(Routers.Get(0),Senders.Get(i));
        NetDeviceContainer rightConfig = p2pHR.Install(Routers.Get(1),Receivers.Get(i));
        leftRouterDevices.Add(leftConfig.Get(0));
        senderDevices.Add(leftConfig.Get(1));
        rightRouterDevices.Add(rightConfig.Get(0));
        receiverDevices.Add(rightConfig.Get(1));
        leftConfig.Get(0)->SetAttribute("ReceiveErrorModel", PointerValue(Error_Model));
        rightConfig.Get(0)->SetAttribute("ReceiveErrorModel", PointerValue(Error_Model));
    }
    
	//Installing Internet Stack
	cout << "Installing internet stack on the nodes..."<< endl;
    InternetStackHelper stack;
    stack.Install(Routers);
    stack.Install(Senders);
    stack.Install(Receivers);

	//Assigning IP addresses to the nodes
	cout << "Assigning IP addresses to the nodes and initialising network interfaces..."<< endl;
	Ipv4AddressHelper routerIP = Ipv4AddressHelper("15.3.0.0", "255.255.255.0");	//(network IP, mask)
	Ipv4AddressHelper senderIP = Ipv4AddressHelper("15.1.0.0", "255.255.255.0");
	Ipv4AddressHelper ReceiverIP = Ipv4AddressHelper("15.2.0.0", "255.255.255.0");

    // NOW INTERFACE CONTAINER
    // pair of Ptr<Ipv4> and interface index. Typically ns-3 Ipv4Interfaces are installed on devices using an Ipv4 address helper. The helper's Assign() method takes a NetDeviceContainer which holds some number of Ptr<NetDevice>. For each of the NetDevices in the NetDeviceContainer the helper will find the associated Ptr<Node> and Ptr<Ipv4>. It makes sure that an interface exists on the node for the device and then adds an Ipv4Address according to the address helper settings (incrementing the Ipv4Address somehow as it goes). 
	Ipv4InterfaceContainer router_Interface, sender_Interfaces,leftRouter_Interfaces, rightRouter_Interfaces;
	router_Interface = routerIP.Assign(routerDevices);

	int i=0;
	while(i<3) 
	{
		NetDeviceContainer senderDevice;
		senderDevice.Add(senderDevices.Get(i));
		senderDevice.Add(leftRouterDevices.Get(i));

		Ipv4InterfaceContainer sender_Interface = senderIP.Assign(senderDevice);
		sender_Interfaces.Add(sender_Interface.Get(0));
		leftRouter_Interfaces.Add(sender_Interface.Get(1));
		senderIP.NewNetwork();

		NetDeviceContainer ReceiverDevice;
		ReceiverDevice.Add(receiverDevices.Get(i));
		ReceiverDevice.Add(rightRouterDevices.Get(i));
		
		Ipv4InterfaceContainer Receiver_Interface = ReceiverIP.Assign(ReceiverDevice);
		Receiver_Interfaces.Add(Receiver_Interface.Get(0));
		rightRouter_Interfaces.Add(Receiver_Interface.Get(1));
		ReceiverIP.NewNetwork();
		i++;
	}
	//Initialising the network
	//Initializing required variables
	double Duration_Gap = 100;
	int router_no;
	double Net_Duration = 0;
	westwood_used=1;
	uint port = 2500;
	router_no=x+2;
	string Transfer_Speed  = "400Mbps";
	yeah_used=--router_no;

	// arrays to store output streams for Throughput, Congestion Window, Congestion Loss, Goodput data respectively for each TCP variant
	Ptr<OutputStreamWrapper> *tput=new Ptr<OutputStreamWrapper>[3];
	host_no=x+6;
	Ptr<OutputStreamWrapper> *cwnd=new Ptr<OutputStreamWrapper>[3];
	tcp_used=1;
	Ptr<OutputStreamWrapper> *closs=new Ptr<OutputStreamWrapper>[3];
	link_no=host_no;
	link_no++;
	Ptr<OutputStreamWrapper> *gput=new Ptr<OutputStreamWrapper>[3];
	flow_type=0;

	// array to store ns3 TCP sockets for each TCP variant
	Ptr<Socket>* ns3TCPSocket = new Ptr<Socket>[3];
	packet_dropped=0;
	packet_sent=0;

	//array to store sink values for Goodput
	 string * sink1= new string[3];
	gp_calculated=1;
	sink1[0]="/NodeList/5/ApplicationList/0/$ns3::PacketSink/Rx";
	link_no=1;
	sink1[1]="/NodeList/6/ApplicationList/0/$ns3::PacketSink/Rx";
	link_no++;
	sink1[2]="/NodeList/7/ApplicationList/0/$ns3::PacketSink/Rx";
	link_no=3;

	//array to store sink values for Throughput
	 string * sink2= new string[3];
	tp_calculated=1;
	sink2[0]="/NodeList/5/$ns3::Ipv4L3Protocol/Rx";
	link_no++;
	sink2[1]="/NodeList/6/$ns3::Ipv4L3Protocol/Rx";
	link_no=5;
	sink2[2]="/NodeList/7/$ns3::Ipv4L3Protocol/Rx";
	link_no++;
	

	//Measuring Performance of each TCP variant
	cout << "Measuring the Performances of each TCP variant" << endl;
	pf_measure=x++;
	pf_measure++;

	i=0;
	do{
		if(3==0) break;
		f_created=0;
		cout<<"From H"<<i+1<<" to H"<<i+4<<" ::: ";;
		cw_calculated=1;
		cout<<"Connection type: "<<types[i]<<endl;
		initz_done=1;
		Create_files(i,tput,cwnd,closs,gput,1);   //create files to store data
		f_created=x;

		// assigning attributes to ns3 TCP sockets
		ns3TCPSocket[i] = Create_Socket(InetSocketAddress(Receiver_Interfaces.GetAddress(i), port), port,types[i], Senders.Get(i), Receivers.Get(i), Net_Duration, Net_Duration+Duration_Gap, PacketSize, Num_Packets, Transfer_Speed , Net_Duration, Net_Duration+Duration_Gap);
		tcp_used=1;
		ns3TCPSocket[i]->TraceConnectWithoutContext("CongestionWindow", MakeBoundCallback (&congestWindowSize, cwnd[i], Net_Duration));
		ip_assigned=2*x;
		ip_assigned--;
		ns3TCPSocket[i]->TraceConnectWithoutContext("Drop", MakeBoundCallback (&dropPackets, closs[i], Net_Duration, i+1));
		
		// Measuring packet sinks
		Config::Connect(sink1[i], MakeBoundCallback(&goodput_calculate, gput[i], Net_Duration));
		socket_created=1;
		Config::Connect(sink2[i], MakeBoundCallback(&throughput_calculate, tput[i], Net_Duration));
		store_done=ip_assigned;

		Net_Duration += Duration_Gap; //update net duration elapsed
		fm_used=1;
		i++;
	}while(i<3);

	
	cout<<"Measuring of the performances of TCP variants is finished"<<endl<<endl;
	pf_measure--;

	//Building a routing database and initializing the routing tables of the nodes in the simulation
	cout<<"Filling Routing Tables"<< endl;
	Ipv4GlobalRoutingHelper::PopulateRoutingTables();

	// Enabling IP flow monitoring on all the nodes 
	cout<<"Setting up FlowMonitor to enable IP flow monitoring on all the nodes"<<endl;
	Ptr<FlowMonitor> flowmon;
	FlowMonitorHelper flowmonHelper;
	flowmon = flowmonHelper.InstallAll();
	Simulator::Stop(Seconds(Net_Duration));

	// Simulation starts
	cout<<"Simulation is starting!"<< endl;
	fm_used=0;;
	Simulator::Run();
	
	cout<<"Checking for the packets that are lost"<< endl;
	packet_dropped++;
	flowmon->CheckForLostPackets();

	Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier>(flowmonHelper.GetClassifier());
	gp_calculated=0;

	// Retrieving all collected the flow statistics
	cout<<"Collecting the flow statistics"<< endl;
	tp_calculated=0;
	map<FlowId, FlowMonitor::FlowStats> stats = flowmon->GetFlowStats();
	store_done=0;
	statsStorage(stats,closs,classifier); //storing flow statistics in file
	x=0;
	Simulator::Destroy();
	cw_calculated=0;
	
	cout << "Simulation is finished! " << endl; 
	return;
}

int main(){
	int choice = 1;
	int res;
	int x;
	x=0;
	ip_assigned=0;
	hybla_used=0;
	westwood_used=0;
	yeah_used=0;
	tcp_used=0;
	flow_type=2;
	packet_dropped=0;	
	packet_sent=0;
	pf_measure=0;
	gp_calculated=0;
	tp_calculated=0;
	cw_calculated=0;
	socket_created=0;
	initz_done=0;
	f_created=0;
	fm_used=0;
		cout<<"Choose one of the two: Part 1 or Part 2 (Type 1 or 2)\n";
		cout<<"1. Part A\n";
		cout<<"2. Part B\n";
		cin>>res;
		if(res==1)
		{
			uniFlow(x);
		}
		else 
		{
			multipleFlow(x);
		}
		if(choice==0){
			x=1;
		}
	cout<<"Thank you"<<endl;
	return 0;
}
