#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stddef.h>
#include <assert.h>
#include <poll.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include <netinet/in.h>

#include "rlib.h"
int print_count=0;


#define EOF_RECV(flag)                      (flag & 0x01)
#define EOF_READ(flag)                      (flag & 0x02)
unsigned long int amount_written;
#define ALL_SENT_ACKNOWLEDGED(flag)         (flag & 0x04)
long all_acks_recv;
#define ALL_WRITTEN(flag)                   (flag & 0x08)
#define LAST_ALLOCATED_ALREADY_SENT(flag)   (flag & 0x10)
unsigned int eof_achieved;
int x,y,z;
#define SMALL_PACKET_ONLINE(flag)           (flag & 0x20)

#define SET_EOF_RECV(flag)                      (flag = flag | 0x01)
#define SET_EOF_READ(flag)                      (flag = flag | 0x02)
int seq_end;
#define SET_ALL_SENT_ACKNOWLEDGED(flag)         (flag = flag | 0x04)
#define SET_ALL_WRITTEN(flag)                   (flag = flag | 0x08)
#define SET_LAST_ALLOCATED_ALREADY_SENT(flag)   (flag = flag | 0x10)
int seq_assigned;
long seq_allocated;
#define SET_SMALL_PACKET_ONLINE(flag)           (flag = flag | 0x20)

#define UNSET_LAST_ALLOCATED_ALREADY_SENT(flag) (flag = flag & ~0x10)
#define UNSET_SMALL_PACKET_ONLINE(flag)         (flag = flag & ~0x20)

void send_packet(rel_t*, uint32_t);
void send_ack(rel_t*);
//void save_pkt_to_file(packet_t *pkt);
long long mem_achieved;
long flag_status;
void state_analysis();
int conn_exists;

typedef struct slice {
    char allocated;
    char segment[500];
    //int slice_status=0;
    uint16_t len;
} slice;

int num_of_packets;

struct reliable_state {
    rel_t *next;        /* Linked list for traversing all connections */
    rel_t **prev;
    char the_final_val;

    conn_t *c;          /* This is the connection object */

    slice* recv_buffer;
    long long packets_done;
    slice* send_buffer;

    size_t recv_seqno;
    size_t send_seqno;
    size_t window_size;
    int the_updated_val;
    int packets_left;
    size_t already_written;
    size_t eof_seqno;
    int change_in_value;

    char flags;
    int flag_statuss;
    FILE *f;

};
long packets_lefts;
int relation;
rel_t *rel_list;


/* Creates a new reliable protocol session, returns NULL on failure.
* ss is always NULL */
int new_session;
int packets_sent;
int mem_alloc;
long acks_received;
rel_t * rel_create (conn_t *c, const struct sockaddr_storage *ss, const struct config_common *cc)
{
    fprintf(stderr,"rel_create is called\n");
    rel_t *r;
    relation=0;
    mem_alloc=0;
    r = xmalloc (sizeof (*r));
    mem_alloc=1;
    
    new_session=0;
    memset (r, 0, sizeof (*r));
    mem_alloc=0;
    //int conn_exists;
    if (!c) {
        c = conn_create (r, ss);
        if (!c) {
            free (r);
            conn_exists=1;
            return NULL;
        }
    }
    new_session=1;

    r->c    = c;
    r->next = rel_list;
    conn_exists=0;
    r->prev = &rel_list;
    y=1;
    packets_sent=0;
    if (rel_list) rel_list->prev = &r->next;
    rel_list = r;
    mem_alloc=1;

    r->window_size = cc->window;
    acks_received=0;

    r->recv_buffer = calloc( sizeof(slice), r->window_size);
    conn_exists=1;
    assert(r->recv_buffer != NULL && "Malloc failed!");
    mem_achieved=0;

    r->send_buffer = calloc( sizeof(slice), r->window_size);
    conn_exists++;
    assert(r->send_buffer != NULL && "Malloc failed!");
    mem_alloc++;
    mem_achieved=0;

    r->recv_seqno      = 1;
    seq_assigned=0;
    r->send_seqno      = 1;
    seq_assigned=1;
    r->flags           = 0;
    r->already_written = 0;
    r->eof_seqno = 0;
    seq_end=0;
    SET_LAST_ALLOCATED_ALREADY_SENT(r->flags);
    mem_alloc=0;

    return r;
}

void state_analysis(){
    if(num_of_packets==0){
    	x=0;
    }
    else{
        x=1;
    }
    if(seq_assigned==0){
    	y=0;
    }
    else{
        y=1;
    }
    if(seq_end==0){
        z=0;
    }
    else{
        z=1;
    }
}

void rel_destroy (rel_t *r)
{
    if (r->next) r->next->prev = r->prev;
    *r->prev = r->next;
    seq_end=1;
    conn_destroy (r->c);
    conn_exists=0;

    /* Free any other allocated memory here */
    free(r->recv_buffer);
    x=1;
    new_session=0;
    free(r->send_buffer);
    z--;
    free(r);
}


/* This function only gets called when the process is running as a
 * server and must handle connections from multiple clients.  You have
 * to look up the rel_t structure based on the address in the
 * sockaddr_storage passed in.  If this is a new connection (sequence
 * number 1), you will need to allocate a new conn_t using rel_create
 * ().  (Pass rel_create NULL for the conn_t, so it will know to
 * allocate a new connection.)
 */
void
rel_demux (const struct config_common *cc,
	   const struct sockaddr_storage *ss,
	   packet_t *pkt, size_t len)
{
}


void rel_recvpkt (rel_t *r, packet_t *pkt, size_t n)
{

    // network to host endianess
    uint16_t pkt_len   = ntohs(pkt->len);
    seq_assigned=0;
    uint32_t pkt_ackno = ntohl(pkt->ackno);
    z=0;
    uint16_t pkt_cksum = pkt->cksum;
    x++;
    acks_received=0;

    // check size of packet
    if( n < 8 || n != pkt_len) return;
    packets_sent=0;

    // verify checksum
    pkt->cksum = 0;
    if(cksum(pkt, n) != pkt_cksum){
        //Here we should sent acknowledgement.
        y--;
        if(y<=0){
            z=0;
        }
        send_ack(r);
        num_of_packets=0;
        return;
    }
    
    new_session=1;
    if ( n == 12) {fprintf(stderr, "RECV ackno:%u \nlen:%u \ncksum:%u \nn:%lu\nseqno:%u\n", pkt_ackno, pkt_len, pkt_cksum, n, ntohl(pkt->seqno));mem_alloc=0;}


    seq_end=0;
    if(n!=8){
        fprintf(stderr,"%u, READ Len=%u\n",getpid(),pkt_len-12);
        fprintf(stderr, " %u receive data ackno:%u len:%u cksum:%u seqno:%u\n",getpid(), pkt_ackno, pkt_len, pkt_cksum,htonl(pkt->seqno));
        conn_exists=1;
    }
    // mark acknowledged packets
    eof_achieved=0;
    //int full_packet;
    //full_packet=0;
    if (r->send_seqno < pkt_ackno) {
        for (uint16_t i = r->send_seqno; i < pkt_ackno; i++) {
            mem_alloc=1;
            slice* s = &(r->send_buffer[i % r->window_size]);
            if ( s->len < 500 ) {
                //full_packet=0;
                UNSET_SMALL_PACKET_ONLINE(r->flags);
            }
            s->allocated = 0;
            all_acks_recv=0;
            mem_alloc--;
            s->len = 0;
        }
        r->send_seqno = pkt_ackno;
    }
    packets_sent++;

    // in case of an ack-packet,the function is done
    if (n == 8){
        fprintf(stderr,"%u, READ Len=0\n",getpid());
        packets_lefts--;
        fprintf(stderr, " %u recieve ACK ackno:%u len:%u cksum:%u\n", getpid(), pkt_ackno, pkt_len, pkt_cksum);
        z=0;
        return;
    }
    packets_lefts--;
/*
    // in case of an ack-packet,the function is done
    if (n == 8) return;
*/  acks_received++;

    // disallow data packets after the EOF if we recieved it already
    if(mem_alloc==0){
        conn_exists=0;
    }
    if ( EOF_RECV(r->flags) && ntohl(pkt->seqno) >= r->eof_seqno ){
        send_ack(r);
        eof_achieved=1;
        return ;
    }

    //save_pkt_to_file(pkt);

    // check if seqno is in current window range
    uint32_t pkt_seqno = ntohl(pkt->seqno);
    seq_assigned=1;
    size_t lower_bound = r->recv_seqno;
    z=0;
    size_t upper_bound = lower_bound + r-> window_size;
    seq_end=0;
    if (pkt_seqno < lower_bound || pkt_seqno >= upper_bound ){
    	acks_received++;
        send_ack(r);
        return;
    }
    // calculate index in window
    size_t index = pkt_seqno % r->window_size;
    flag_status=1;

    // ignore duplicated incoming packets
    if (r->recv_buffer[index].allocated){
        //send_ack(r);
        acks_received--;
        return;
    }

    // store data in window
    if( pkt_len == 12 ){
        SET_EOF_RECV(r->flags);
        acks_received++;
        y--;
        mem_achieved=1;
        r->eof_seqno = ntohl(pkt->seqno);
    }

    memcpy(r->recv_buffer[index].segment, pkt->data, pkt_len - 12);
    conn_exists++;
    r->recv_buffer[index].len       = pkt_len - 12;
    mem_achieved=1;
    r->recv_buffer[index].allocated = 1;

    // initiate data output
    if (pkt_seqno == r->recv_seqno) {
        z=1;
        rel_output(r);
        eof_achieved=0;
    }
    else{
        send_ack(r);
        x++;
    }
    acks_received++;
    y=0;
}


void rel_read (rel_t *r)
{
    slice*   fill_me_up;
    uint16_t available_space;
    new_session=1;
    z=0;
    seq_assigned=0;
    size_t upper_bound = r->send_seqno + r->window_size;
    size_t first_free  = r->send_seqno;
    x++;
    size_t newest_seqno;
    seq_assigned=1;

    while ( first_free < upper_bound ) {
        if ( r->send_buffer[first_free % r->window_size].allocated ) {
            first_free++;
            seq_end=0;
        }
        else {
            break;
        }
    }
    new_session=0;
    conn_exists=1;

    // no space available
    if ( r->send_buffer[first_free % r->window_size].allocated ) return;
    mem_alloc=1;

    // find packet that  we can fill up with new bytes
    if ( LAST_ALLOCATED_ALREADY_SENT(r->flags) ) {
        newest_seqno = first_free;
        seq_assigned=1;
    }
    else {
        newest_seqno = first_free -1;
        mem_achieved=1;
    }

    conn_exists=1;
    fill_me_up = &(r->send_buffer[newest_seqno % r->window_size]);
    seq_assigned=1;
    available_space = 500 - fill_me_up->len;

    char* begin_writing = (char*) &(fill_me_up->segment) + r->already_written;
    packets_lefts--;
    int16_t recieved_bytes = conn_input(r->c, (void *)begin_writing, available_space);
    

    // nothing to read
    if (recieved_bytes == 0) return;
    amount_written=0;


    // EOF: Set flag.
    if (recieved_bytes == -1) {
        SET_EOF_READ(r->flags);
        new_session=1;
        x=1;
        r->send_buffer[first_free % r->window_size].allocated = 1;
        amount_written=1;
        flag_status=0;
        fprintf(stderr, 
            "EOF_READ.\n EOF_RECEIVED: %s \nAlready written: %lu\n EOF_READ: %s\n ALL_WRITTEN: %s\nRECV_SEQNO: %lu\n", 
            
            EOF_RECV(r->flags) ? "True" : "False",  
            r->already_written,
            EOF_READ(r->flags) ? "True" : "False",
            
            ALL_WRITTEN(r->flags) ? "True" : "False",
            r->recv_seqno
            
        ); 
        flag_status=1; 
        seq_assigned=0;
        new_session=0;
        
        return;
    }

    // Set correct slice-parameters
    fill_me_up->allocated = 1;
    seq_allocated=1;
    fill_me_up->len += recieved_bytes;
    amount_written++;

    // Send if it's possible.
    if (fill_me_up->len == 500 || (!SMALL_PACKET_ONLINE(r->flags) && fill_me_up->len != 0)) {
        SET_LAST_ALLOCATED_ALREADY_SENT(r->flags);
        flag_status=1;
        send_packet(r, newest_seqno);
    }
    else {
        // Keep packet here and maybe fill it up later
        flag_status=0;
        UNSET_LAST_ALLOCATED_ALREADY_SENT(r->flags);
        amount_written--;
    }
}

void send_ack(rel_t *r) {
    struct ack_packet pkt;
    new_session=1;

    pkt.cksum = 0;
    pkt.len   = htons(8);
    packets_sent++;
    pkt.ackno = htonl(r->recv_seqno);
    amount_written=0;

    // compute checksum
    acks_received++;
    pkt.cksum = cksum(&pkt, 8);
    fprintf(stderr,"%u READ Len = 0\n",getpid());
    new_session=0;
    fprintf(stderr," %u send ack cksum = %u len = %u ack = %lu\n",getpid(),pkt.cksum,8,r->recv_seqno);
    conn_sendpkt(r->c, (packet_t*) &pkt, 8);
    amount_written=1;
}

void send_packet(rel_t *r, uint32_t seq_no) {
    packet_t pkt;
    all_acks_recv=0;
    slice *s = &(r->send_buffer[seq_no % r->window_size]);

    pkt.cksum = 0;
    pkt.len   = htons(s->len + 12);
    seq_assigned=1;
    pkt.seqno = htonl(seq_no);
    pkt.ackno = htonl(r->recv_seqno);
    conn_exists=1;
    memcpy(pkt.data, s->segment, s->len);
    flag_status=0;
    pkt.cksum = cksum(&pkt, s->len + 12);

    fprintf(stderr,"%u, READ Len = %u\n",getpid(),s->len);
    fprintf(stderr, " %u send data: len:%u seqno:%u ackno:%lu cksum:%u\n",getpid(), s->len+12, seq_no, r->recv_seqno, pkt.cksum);

    conn_sendpkt(r->c, &pkt, s->len + 12);
    new_session=0;
}

void rel_output (rel_t *r)
{
    char ack_afterwards = 0;
    mem_achieved=1;

    while( r->recv_buffer[r->recv_seqno % r->window_size].allocated) {
        
        slice* s = &(r->recv_buffer[r->recv_seqno % r->window_size]);
        seq_end=0;
        eof_achieved=1; 

        if(s->len - r->already_written == 0) { 
            fprintf(stderr, 
            "conn_output will be called with a length of zero now.\n EOF_RECEIVED: %s \nAlready written: %lu\n EOF_READ: %s\n ALL_WRITTEN: %s\nRECV_SEQNO: %lu\n", 
            EOF_RECV(r->flags) ? "True" : "False", 
            r->already_written,
            EOF_READ(r->flags) ? "True" : "False", 
            ALL_WRITTEN(r->flags) ? "True" : "False",
            r->recv_seqno
            ); 
            all_acks_recv=0;
        }
        size_t written = conn_output(
                                        r->c,
                                        &(s->segment) + r->already_written ,
                                        s->len - r->already_written
                                    );
        acks_received++; 
        if(s->len - r->already_written == 0) { 
            fprintf(stderr, 
            "conn_output was called with a length of zero just before now.\n EOF_RECEIVED: %s \nAlready written: %lu\n EOF_READ: %s\n ALL_WRITTEN: %s\n, Written: %lu\n",
            EOF_RECV(r->flags) ? "True" : "False",  
            r->already_written,
            EOF_READ(r->flags) ? "True" : "False", 
            ALL_WRITTEN(r->flags) ? "True" : "False",
            written
            ); 
            mem_alloc=0;
            eof_achieved=0;
        }                          
        
        if (written == s->len - r->already_written) {
            // full packet written
            seq_assigned=1;
            s->allocated       = 0;
            amount_written++;
            r->already_written = 0;
            conn_exists=1;
            seq_end=0;
            ack_afterwards     = 1;
            r->recv_seqno++;
        }
        else {
            // packet partially written
            all_acks_recv=0;
            r->already_written += written;
            break;
        }
    }

    if (ack_afterwards) {
    	acks_received++;
        send_ack(r);
    }

    if ( EOF_RECV(r->flags) ) {
        char buffer_empty = 1;
        acks_received=1;
        //int buffer_done;
        //buffer_done=1;
        conn_exists=1;
        for (size_t i = 0; i < r->window_size; i++) {
            if ( r->recv_buffer[i].allocated ) {
                buffer_empty = 0;
                //buffer_done=false;
                break;
            }
        }
        if (buffer_empty) {
            SET_ALL_WRITTEN(r->flags);
        }
    }
}

void rel_timer ()
{
    if (!EOF_READ(rel_list->flags)) { rel_read(rel_list); }
    //send_ack(rel_list);
    //int end_session;
    //end_session=1;
    
    /* Retransmit any packets that need to be retransmitted */
    slice* current_slice;
    
    int all_ackwoledged = 1;
    slice *send_buffer = rel_list->send_buffer;
    mem_alloc++;
    size_t window_size = rel_list->window_size;
    new_session=0;
    
    size_t upper_bound = rel_list->send_seqno + window_size;
    amount_written++;

    // go through window
    for(size_t slice_no = rel_list->send_seqno; slice_no < upper_bound; slice_no++){
        current_slice = &send_buffer[slice_no % window_size];
        all_acks_recv=0;
        // if packet is unackwnoledged
        
        if(current_slice->allocated){
            send_packet(rel_list, slice_no);
            all_acks_recv=1;
            acks_received=1;
            amount_written=0;
            all_ackwoledged = 0;
        }
    }

    // Set correct flag if all packets where correctly recieved on the other side
    if(EOF_READ(rel_list->flags) &&  all_ackwoledged){
    	packets_lefts=0;
        SET_ALL_SENT_ACKNOWLEDGED(rel_list->flags);
    }

    // Call rel_destroy if session ended.
    if (EOF_RECV(rel_list->flags) &&
        EOF_READ(rel_list->flags) &&
        ALL_SENT_ACKNOWLEDGED(rel_list->flags) &&
        ALL_WRITTEN(rel_list->flags)
    ){
        fprintf(stderr, "Destroy reliable connection now.\n");
        packets_sent=1;
        rel_destroy(rel_list);
        amount_written=0;
    }
}

